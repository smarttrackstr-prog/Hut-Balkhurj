# بناء APK من الهاتف فقط — حُط بالخرج

1. ارفع محتويات هذا المجلد إلى مستودع GitHub جديد باسم `hut-balkhurj`.
2. تأكد أن الملف `.github/workflows/build-apk.yml` موجود.
3. افتح تبويب **Actions** في GitHub.
4. شغّل **Build Android APK** أو انتظر تشغيله تلقائياً بعد الرفع إلى `main`.
5. بعد نجاح العملية افتح التشغيل الناجح ثم **Artifacts**.
6. نزّل `hut-balkhurj-debug-apk` وفك الضغط لتحصل على `app-debug.apk`.

مهم: هذا APK تجريبي Debug. لا يُنشر على Google Play بهذه الصيغة مباشرة؛ للنشر سننشئ لاحقاً نسخة Release موقعة.
