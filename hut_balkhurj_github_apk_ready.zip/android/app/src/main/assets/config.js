window.HUT_CONFIG={SUPABASE_URL:'https://eqkmvoaesrtwspcxiomp.supabase.co',SUPABASE_ANON_KEY:'sb_publishable_RbcVslaoJvZylPN9stFwMw_Qt_T-fEf'};
